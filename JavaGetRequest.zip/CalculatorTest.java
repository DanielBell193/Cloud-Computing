class CalculatorTest {

	void testAdd() {
		Calculator c = new Calculator();
		System.out.println(c.add(20,1));
	}

  void testMinus() {
		Calculator c = new Calculator();
		System.out.println(c.minus(20,1));
	}
	
	void testDivide() {
		Calculator c = new Calculator();
		System.out.println(c.divide(20,1));
	}
	
	void testMultiply() {
		Calculator c = new Calculator();
		System.out.println(c.multiply(20,1));
	}

	void testModulo() {
		Calculator c = new Calculator();
		System.out.println(c.modulo(20,1));
	}
	
	void testSquare() {
		Calculator c = new Calculator();
		System.out.println(c.square(3));
	}

}