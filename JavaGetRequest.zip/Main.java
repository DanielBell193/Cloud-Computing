class Main {

  public static void main(String[] args) {
    CalculatorTest t = new CalculatorTest();
    t.testAdd();
    t.testMinus();
  }

}