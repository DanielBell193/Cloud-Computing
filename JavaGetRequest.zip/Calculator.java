// http://zetcode.com/java/getpostrequest/

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Calculator {

  public final static String URL_MODULO = "https://modulo20201126113348.azurewebsites.net/api/HttpExample";
  public final static String URL_SQUARE = "";
  public final static String URL_DIVIDE = "https://z2gphwn8jh.execute-api.us-east-1.amazonaws.com/default/Divide";
  public final static String URL_MULTIPLY = "https://europe-west2-webcalc.cloudfunctions.net/Multiply";
  public final static String URL_ADD = "http://add.webcalc.qpc.hal.davecutting.uk";
  public final static String URL_MINUS = "http://subtract.webcalc.qpc.hal.davecutting.uk";

  public static double ans = 0.1; 

  private static HttpURLConnection con;

  public double add(double x, double y) {
    String params = "?x=" + x + "&y=" + y; 
    String str_url = URL_ADD + params;
    System.out.println(str_url);
    try {
      ans = getResponse(str_url);
    }
    catch(IOException e) {
      e.printStackTrace();
    }
    return ans;
  }

  public double minus(double x, double y) {
    String params = "?x=" + x + "&y=" + y; 
    String str_url = URL_MINUS + params;
    System.out.println(str_url);
    try {
      ans = getResponse(str_url);
    }
    catch(IOException e) {
      e.printStackTrace();
    }
    return ans;
  }

  public double divide(double x, double y) {
    String params = "?x=" + x + "&y=" + y; 
    String str_url = URL_DIVIDE + params;
    System.out.println(str_url);
    try {
      ans = getResponse(str_url);
    }
    catch(IOException e) {
      e.printStackTrace();
    }
    return ans;
  }

  public double multiply(double x, double y) {
    String params = "?x=" + x + "&y=" + y; 
    String str_url = URL_MULTIPLY + params;
    System.out.println(str_url);
    try {
      ans = getResponse(str_url);
    }
    catch(IOException e) {
      e.printStackTrace();
    }
    return ans;
  }

  public double modulo(double x, double y) {
    String params = "?x=" + x + "&y=" + y; 
    String str_url = URL_MODULO + params;
    System.out.println(str_url);
    try {
      ans = getResponse(str_url);
    }
    catch(IOException e) {
      e.printStackTrace();
    }
    return ans;
  }

  public double square(double x) {
    String params = "?x=" + x; 
    String str_url = URL_SQUARE + params;
    System.out.println(str_url);
    try {
      ans = getResponse(str_url);
    }
    catch(IOException e) {
      e.printStackTrace();
    }
    return ans;
  }

  public static double getResponse(String str_url) throws IOException {

    var url = "" + str_url;

    try {

      var myurl = new URL(url);
      con = (HttpURLConnection) myurl.openConnection();

      con.setRequestMethod("GET");

      StringBuilder content;

      try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {

        String line;
        content = new StringBuilder();

        while ((line = in.readLine()) != null) {
          content.append(line);
          content.append(System.lineSeparator());
        }
      }

      String response = content.toString();
      System.out.println(response);

      String str_ans = "";
      str_ans = response.substring(response.lastIndexOf(":") + 1);
      str_ans = str_ans.substring(0, str_ans.length() - 2);
      System.out.println("ANS: "+ str_ans);

      ans = Double.parseDouble(str_ans);

    } finally {

      con.disconnect();
    }
    return ans;
  }

}